<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class registro extends Model
{
	public function getRouteKeyName()
	{
	    return 'folio';
	}
    protected $table = 'registro';
	protected $primaryKey = 'id';
	protected $fillable =[
		'status',
		'tipoPostulacion',
		'folio',
		'id_convocatoria',
		'tipoPostulacion',
		'usuarioTemporal',
		'contrasenia',
		'nombre',
		'apellidoPaterno',
		'apellidoMaterno',
		'nombreColectivo',
		'fechaNacimiento',
		'id_nacionalidad', // Llave foránea, representa al id del catálogo de nacionalidades.
		'lugarResidencia',
		'email',
		'telefono',
		'extension',
		'semblanza',
		'documentosPersonales',
		'disciplina',
		'tituloProyecto',
		'anoRealizacion',
		'descripcionProyecto',
		'adjuntarProyecto',
		'bases',
		'verificacion',
		'privacidad',
		'created_at',
		'updated_at',
     ];
}
