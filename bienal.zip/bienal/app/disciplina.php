<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class disciplina extends Model
{
    protected $table = 'disciplinas';
	protected $primaryKey = 'id';
}
