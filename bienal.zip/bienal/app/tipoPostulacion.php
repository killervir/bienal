<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tipoPostulacion extends Model
{
    protected $table = 'tipoPostulacion';
	protected $primaryKey = 'id';
}
