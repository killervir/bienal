<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class nacionalidad extends Model
{
    protected $table = 'nacionalidad';
	protected $primaryKey = 'id';
}
