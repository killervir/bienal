<h1>Hola {{$name}}</h1>
					<p>Muchas gracias por haber registrado tu proyecto. Tu ficha de registro a la XIX Bienal de Fotografía se recibió de manera correcta.</p>
					<h2>Número de folio: {{$folio}}</h2>
					<p>Los resultados se publicarán en el sitio oficial de la Bienal así como en nuestras redes sociales: <a href="http://bienaldefotografia.com.mx">bienaldefotografia.com.mx</a></p>
					<h3>Centro de la Imagen</h3>
					XIX Bienal de Fotografía<br>
					bienaldefotografia@cultura.gob.mx<br>
					<a href="http://bienaldefotografia.com.mx">bienaldefotografia.com.mx</a></p>
					<p>Plaza de la Ciudadela 2, Centro Histórico, C.P. 06040 Alcaldía Cuauhtémoc, Ciudad de México<br>
					<a href="https://centrodelaimagen.cultura.gob.mx/"> centrodelaimagen.cultura.gob.mx</a></p>
		