{{-- js --}}
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

{{-- Estos son para agregar o quitar participantes de la postulacion colectiva --}}
<script>
//when the Add Field button is clicked
$("#add").click(function (e) {
    //Append a new row of code to the "#items" div
    $("#items").append('<div><input class="form-control" id="integrantes[]" name="integrantes[]" type="text" /><button class="delete btn btn-outline-danger" ">Eliminar</button></div>');
});

    $("body").on("click", ".delete", function (e) {
        $(this).parent("div").remove();
    });

{{-- @if(old('tipoPostulacion'))

    @else --}}
    $("#tipoPostulacion").change(function () {
        var selectedTipoPostulacion = $(this).children("option:selected").val();
        if(selectedTipoPostulacion==1){
           $("#divIndividual").css("display", "block");
           $("#divColectivo").css("display", "none");
           $("#divRepresentante").css("display", "none");
           $("#divColectiva").css("display", "none");
           $("#divFormulario").css("display", "block");
           $("#divProyecto").css("display", "block");
           $("#divCondiciones").css("display", "block");

           }
        if(selectedTipoPostulacion==2){
            $("#divIndividual").css("display", "none");
            $("#divColectivo").css("display", "block");
            $("#divRepresentante").css("display", "block");
            $("#divColectiva").css("display", "block");
           $("#divFormulario").css("display", "block");
           $("#divProyecto").css("display", "block");
           $("#divCondiciones").css("display", "block");
        }
    });
$("#tipoPostulacion").bind("change", function(){}).change();
{{--@endif--}}

$('#documentosPersonales').on("change",function () {
    //var id=$(this).attr('id');

    id="#documentosPersonales";
    console.log(id);
    var archivo=$(id).val();

    var fileExtension = ['pdf'];
    if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
        alert("Solo se permiten archivos '.pdf'!");
        this.value = '';
        $(id).focus();
        return false;
        //$('#spanFileName').html("Solo se aceptan archivos '.pdf'!");
    }
    else {
        //$('#spanFileName').html(this.value);


        //do what ever you want
        if (this.files.length > 0) {
            $.each(this.files, function (index, value) {
                var tamanio=Math.round((value.size / 1024));
                if(tamanio>2048) {
                    alert("El archivo excede los 2Mb, por favor verifique.");
                    $(id).val('');
                    $(id).value = '';
                    $(id).focus();
                    return false;
                }
            })
        }
    }
});
$('#adjuntarProyecto').on("change",function () {
    //var id=$(this).attr('id');
   //valor
    id="#adjuntarProyecto";
    console.log(id);
    var archivo=$(id).val();

    var fileExtension = ['pdf'];
    if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
        alert("Solo se permiten archivos '.pdf'!");
        this.value = '';
        $(id).focus();
        return false;
        //$('#spanFileName').html("Solo se aceptan archivos '.pdf'!");
    }
    else {
        //$('#spanFileName').html(this.value);


        //do what ever you want
        if (this.files.length > 0) {
            $.each(this.files, function (index, value) {
                var tamanio=Math.round((value.size / 1024));
                if(tamanio>15360) {
                    alert("El archivo excede los 15Mb, por favor verifique.");
                    $(id).val('');
                    $(id).value = '';
                    $(id).focus();
                    return false;
                }
            })
        }
    }
});
</script>

