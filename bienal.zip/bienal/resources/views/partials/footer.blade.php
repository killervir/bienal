<footer>
	<div class="container">
		<div class="col-md-12 redes text-right pt-2">
			<a target="_blank" href="https://www.facebook.com/centrodelaimagen.mx/"><i class="fab fa-facebook-square"></i></a>
			<a target="_blank" href="https://twitter.com/cimagen"><i class="fab fa-twitter"></i></a>
			<a target="_blank" href="https://www.instagram.com/cimagen/"><i class="fab fa-instagram"></i></a>
			<a target="_blank" href="https://www.youtube.com/channel/UCBJt7yMdqzvdipc-bqUuvPw"><i class="fab fa-youtube"></i></a>
		</div>
		<div class="logos">
			<a target="_blank" href="https://www.gob.mx/cultura"><img src="{{ asset('public/img/logo-sc-w.svg') }}" alt=""></a>
			<a target="_blank" href="https://centrodelaimagen.cultura.gob.mx/"><img src="{{ asset('public/img/logo-centro-de-la-imagen.svg') }}" alt=""></a>
		</div>
	</div>
</footer>