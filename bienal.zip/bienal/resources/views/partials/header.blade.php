    <header class="header-interiores container-fluid">
		<div class="row">
			<div class="col-md-5 logo-ci"><img src="{{ asset('public/img/logo-centro-de-la-imagen.svg') }}" alt=""></div>
			<div class="col-md-7 logo-bienal"><img src="{{ asset('public/img/logo-xixbienal.svg') }}" alt=""></div>
		</div>
	  </header>