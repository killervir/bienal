@extends('admin.layout')
@section('content')
    <div class="container col-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h2>Listado de registros</h2>
            </div>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Folio</th>
							<th>Tipo postulación</th>							
							<th>Datos Personales</th>
							<th>Proyecto</th>
                            <th>acciones</th>
                            <th>Verificación</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($registros as $registro)
                            <tr>
                                <td>{!! $registro->folio !!}</td>
								<td>{!! $registro->tipoPostulacion==1 ? 'Individual' : 'Colectiva' !!} 
								<td><a href="{{asset('public/storage/'.$registro->documentosPersonales)}}" target="_blank">Ver PDF</a></td>
								<td><a href="{!! asset('public/storage/'.$registro->adjuntarProyecto) !!}" target="_blank">Ver Proyecto</a></td>
                                <td class="acciones-btns">
                                    <a data-toggle="tooltip" data-placement="top" title="Ver registro" class="" href="{{route('xix.show',$registro->folio)}}"><i class="fas fa-folder"></i></a>
                                    @if(auth()->user()->hasRoles([5]))
                                    <a data-toggle="tooltip" data-placement="top" title="Editar" class="" href="{{route('xix.edit',$registro->folio)}}"><i class="fas fa-pencil-alt"></i></a>
                                    @endif
                                </td>
                                <td>
                                    @if($registro->verificacion==0)
                                    <a data-toggle="tooltip" data-placement="top" title="Verificar" class="c-verde" href="#"><i class="fas fa-check" data-toggle="modal" data-target="{{'#verificar'.$registro->folio}}"></i></a>
                                    @elseif($registro->verificacion==1)
                                    <font color="green">Verificado</font>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
			    {{ $registros->links()}}
        </div>
    </div>
<!-- Modal  verificar -->
@foreach($registros as $r)
<div class="modal fade" id="{{'verificar'.$r->folio}}" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">{{$r->folio}}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        {!! Form::model($registro, ['method' => 'PATCH', 'route' => ['admin.verificarRegistro', $r->folio]]) !!}        
          <h5> ¿Está seguro que desea verificar el registro con el folio {{'"'.$r->folio.'"'}}</h5>
          <button class="btn btn-success">Sí, verificar</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>
@endforeach
{{-- Termina modal de verificar --}}
@stop
