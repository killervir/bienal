@extends('admin.layout')
@section('content')
    <div class="container col-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h2>Listado de registros verificados</h2>
            </div>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Folio</th>
							<th>Tipo postulación</th>							
							<th>Datos Personales</th>
							<th>Proyecto</th>
                            <th>Ver</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($registros as $registro)
                            <tr>
                                <td>{!! $registro->folio !!}</td>
								<td>{!! $registro->tipoPostulacion==1 ? 'Individual' : 'Colectiva' !!} 
								<td><a href="{{asset('public/storage/'.$registro->documentosPersonales)}}" target="_blank">Ver PDF</a></td>
								<td><a href="{!! asset('public/storage/'.$registro->adjuntarProyecto) !!}" target="_blank">Ver Proyecto</a></td>
                                <td class="acciones-btns">
                                    <a data-toggle="tooltip" data-placement="top" title="Ver registro" class="" href="{{route('xix.show',$registro->folio)}}"><i class="fas fa-folder"></i></a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
			    {{ $registros->links()}}
        </div>
    </div>
@stop
