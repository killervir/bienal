@extends('partials.layout')
@section('content')
<h1><center>Ya se había registrado con anterioridad.<br><br>
	<a class="btn btn-outline-danger" href="{{route('home')}}">Regresar al inicio</a>
</center></h1>
@endsection