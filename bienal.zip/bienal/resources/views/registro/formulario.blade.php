@extends('partials.layout')
@section('content')
@csrf
<form role="form" action="{{route('xix.store')}}" method="post" enctype="multipart/form-data">
	<input id="tipo" name="tipo" type="hidden" value="{{old('tipo')}}">
<title>Ficha de registro </title>
<div class="container">
	<div class="row">
	<div class="col-md-12">
		<h1>Ficha de registro</h1>
		<p>*Estos campos son obligatorios</p>
		<br>
	</div> {{-- col --}}
	</div> {{-- row --}}
	@include('partials.postulacion')

    <input type="hidden" name="folio" id="folio" value="{{$folio}}">
    <div id="divIndividual" style="display:none"> <h2>Postulación individual</h2> </div>
    <div id="divColectivo" style="display:none"><h2>Postulación colectiva</h2></div>
    <div id="divRepresentante" style="display:none"><h3>Información del representante</h3></div>
    <div id="divFormulario" style="display:none">@include('partials.formularioGeneral')</div>
    <div id="divColectiva" style="display:none"><h3>Información del colectivo</h3>
    	<br>@include('partials.rowColectiva')
    </div>
	
	<hr>
		
		<div id="divProyecto" style="display:none">@include('partials.proyecto')</div>
	<div id="divCondiciones" style="display:none">@include('partials.condiciones')</div>
	
	<div class="row">
		<div class="col-md-12 text-center mt-5 mb-3">
			<button type="submit" class="btn btn-outline-success">Enviar</button>
			<br><br>
		</div>
	</div> {{-- row --}}

</div> {{-- container --}}
</form>
@endsection


