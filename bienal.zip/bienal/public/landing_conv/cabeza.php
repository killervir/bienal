  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">
			<div class="logo mr-auto">
        		<a href="http://reactivacion.cultura.gob.mx"><img src="{{ asset('public/landing_conv/img/logotop.svg') }}" alt="Contigo en la distancia" class="img-fluid"></a>
      		</div>
 			<nav class="nav-menu d-none d-lg-block">
        		<ul>
					<li class="active"><a href="http://reactivacion.cultura.gob.mx">Convocatoria</a></li>
					<li><a href="http://reactivacion.cultura.gob.mx/presentacion">Presentación</a></li>
					<li><a href="http://reactivacion.cultura.gob.mx#contacto">Contacto</a></li>
					<li><a href="http://reactivacion.cultura.gob.mx/LoginT" target="_blank" style="color: #dd463c; font-weight: normal">Iniciar sesión</a></li>
				</ul>
      		</nav>
			<!-- <div class="header-social-links">
				<a href="#" class="twitter"><i class="icofont-twitter"></i></a>
				<a href="#" class="facebook"><i class="icofont-facebook"></i></a>
				<a href="#" class="instagram"><i class="icofont-instagram"></i></a>
				<a href="#" class="linkedin"><i class="icofont-linkedin"></i></i></a>
     		</div>-->
    	</div>
  </header>


<!-- End Header -->