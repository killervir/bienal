<footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">
			<div class="col-md-9 m-auto">
          		<img src="assets/img/pie.svg" alt=""/> 
			</div>
		</div>
      </div>
    </div>

    <div class="container d-md-flex py-4">
      <div class="mr-md-auto text-center text-md-left">
        <div class="copyright">
        <!--  &copy; Copyright <strong><span>Lumia</span></strong>. All Rights Reserved-->
        </div>
        <div class="credits">
          <!-- All the links in the footer should remain intact. -->
          <!-- You can delete the links only if you purchased the pro version. -->
          <!-- Licensing information: https://bootstrapmade.com/license/ -->
          <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/lumia-bootstrap-business-template/ -->
         
        </div>
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
       <a href="https://twitter.com/CC_LosPinos" target="_blank" class="twitter"><i class="bx bxl-twitter"></i></a>
        <a href="https://www.instagram.com/cc_lospinos/" target="_blank" class="instagram"><i class="bx bxl-instagram"></i></a>
      </div>
    </div>
  </footer>