
<?php echo csrf_field(); ?> 
<div class="row">
	<div class="col-md-12">
		<h3><center><font><?php echo e($postType); ?></font></center></h3>
	</div> 
</div> 
<div class="row">
	<div class="col-md-4 form-group">
		<label>Nombre <?php echo e($adicional); ?></label>
		<input type="text" name="nombre" id="nombre" class="form-control" value="<?php echo e(old('nombre')); ?>">
		<?php echo $errors->first('nombre','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-4 form-group">
		<label>Apellido materno <?php echo e($adicional); ?></label>
		<input type="text" name="apellidoPaterno" id="apellidoPaterno" class="form-control" value="<?php echo e(old('apellidoPaterno')); ?>">
		<?php echo $errors->first('apellidoPaterno','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-4 form-group">
		<label>Apellido paterno <?php echo e($adicional); ?></label>
		<input type="text" name="apellidoMaterno" id="apellidoMaterno" class="form-control" value="<?php echo e(old('apellidoMaterno')); ?>">
		<?php echo $errors->first('apellidoMaterno','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
</div> 
<div class="row">
	<div class="col-md-4 form-group">
		<label>Fecha de nacimiento <?php echo e($adicional); ?></label>
		<input type="date" name="fechaNacimiento" id="fechaNacimiento" class="form-control" value="<?php echo e(old('fechaNacimiento')); ?>">
		<?php echo $errors->first('fechaNacimiento','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-4 form-group">
		<label>Nacionalidad <?php echo e($adicional); ?></label>
		<select name="nacionalidad" id="nacionalidad" class="form-control" value="<?php echo e(old('nacionalidad')); ?>">
			<option hidden disabled selected>Seleccione una opción</option>
		</select>
		<?php echo $errors->first('nacionalidad','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-4 form-group">
		<label>Lugar de residencia <?php echo e($adicional); ?></label>
		<input type="text" name="lugarResidencia" id="lugarResidencia" class="form-control" value="<?php echo e(old('lugarResidencia')); ?>">
		<?php echo $errors->first('lugarResidencia','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	
</div> 
<div class="row">
	<div class="col-md-4 form-group">
		<label>Correo electrónico <?php echo e($adicional); ?></label>
		<input type="email" name="email" id="email" class="form-control" value="<?php echo e(old('email')); ?>">
		<?php echo $errors->first('email','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-4 form-group">
		<label>Confirmación del correo electrónico <?php echo e($adicional); ?></label>
		<input type="email" name="emailConfirmacion" id="emailConfirmacion" class="form-control" value="<?php echo e(old('emailConfirmacion')); ?>">
		<?php echo $errors->first('emailConfirmacion','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-4 form-group">
		<label>Teléfono fijo o movil de contacto <?php echo e($adicional); ?></label>
		<input type="number" name="telefono" id="telefono" class="form-control" value="<?php echo e(old('telefono')); ?>">
		<?php echo $errors->first('telefono','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	
</div> 
<div class="row">
	<div class="col-md-4 form-group">
		<label>Extensión</label>
		<input type="number" name="extension" id="extension" class="form-control" value="<?php echo e(old('extension')); ?>">
		<?php echo $errors->first('extension','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-4 form-group">
		<label>Semblanza <?php echo e($adicional2); ?></label>
		<textarea name="semblanza" id="semblanza" class="form-control"><?php echo e(old('semblanza')); ?></textarea>
		<?php echo $errors->first('semblanza','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-4 form-group">
		<label>Adjuntar documentos personales <?php echo e($adicional); ?></label>
		<input type="file" name="documentosPersonales" id="documentosPersonales" class="form-control" value="<?php echo e(old('documentosPersonales')); ?>">
		<p><font color="blue">Un solo documento (PDF, no mayor a 2MB) con documentos personales: identificación oficial vigente, Curriculum vitae y CURP. En caso de ser extranjero presentar comprobante de residencia legal en México.</font></p>
		<?php echo $errors->first('documentosPersonales','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
</div> 
<?php /**PATH C:\laragon\www\bienal\resources\views/partials/formularioGeneral.blade.php ENDPATH**/ ?>