    <header class="header-admin container-fluid">
		<div class="row">
			<div class="col-sm-6 col-6 col-md-5 logo-ci"><img src="<?php echo e(asset('public/img/logo-centro-de-la-imagen.svg')); ?>" alt=""></div>
			<div class="col-sm-6 col-6 col-md-7 logo-bienal"><img src="<?php echo e(asset('public/img/logo-xixbienal-w.svg')); ?>" alt=""></div>
		</div>
	  </header><?php /**PATH /var/www/html/bienal/resources/views/admin/header.blade.php ENDPATH**/ ?>