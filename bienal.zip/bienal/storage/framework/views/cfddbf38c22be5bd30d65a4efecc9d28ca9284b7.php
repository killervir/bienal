
<?php $__env->startSection('content'); ?>
<?php echo e($contacto->nombre); ?>

<?php echo e($contacto->email); ?>

<?php echo e($contacto->descripcion); ?>

<?php echo e($contacto->telefono1); ?>

<?php echo e($contacto->extension1); ?>

<?php echo e($contacto->telefono2); ?>

<?php echo e($contacto->extension2); ?>

<?php echo e($contacto->horario); ?>

<?php echo e($contacto->direccion); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bienal/resources/views/admin/verContacto.blade.php ENDPATH**/ ?>