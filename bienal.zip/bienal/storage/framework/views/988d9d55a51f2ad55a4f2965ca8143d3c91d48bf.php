<div>
    Hi, This is : 
</div>
<?php /**PATH /var/www/html/bienal/resources/views/emails/name.blade.php ENDPATH**/ ?>