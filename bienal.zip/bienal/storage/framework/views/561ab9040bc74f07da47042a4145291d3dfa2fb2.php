<?php echo csrf_field(); ?>
<div class="row">
	<div class="col-md-4 form-group">
		<label>*Nombre completo o Nombre del área</label>
		<input type="text" name="nombre" id="nombre" class="form-control" value="<?php echo e(old('nombre', $contacto->nombre)); ?>">
		<?php echo $errors->first('nombre','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-4 form-group">
		<label>*Correo electrónico</label>
		<input type="email" name="email" id="email" class="form-control" value="<?php echo e(old('email', $contacto->email)); ?>">
		<?php echo $errors->first('email','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-4 form-group">
		<label>Descripción</label>
		<input type="text" name="decripcion" id="decripcion" class="form-control" value="<?php echo e(old('decripcion', $contacto->decripcion)); ?>">
		<?php echo $errors->first('decripcion','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="w-100"></div> 
	<div class="col-md-4 form-group">
		<label>*Teléfono de contacto principal</label>
		<input type="number" name="telefono1" id="telefono1" class="form-control" value="<?php echo e(old('telefono1', $contacto->telefono1)); ?>">
		<?php echo $errors->first('telefono1','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-4 form-group">
		<label>Extensión del teléfono 1</label>
		<input type="number" name="extension1" id="extension1" class="form-control" value="<?php echo e(old('extension1', $contacto->extension1)); ?>">
		<?php echo $errors->first('extension1','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-4 form-group">
		<label>Teléfono secundario de contacto</label>
		<input type="number" name="telefono2" id="telefono2" class="form-control" value="<?php echo e(old('telefono2', $contacto->telefono2)); ?>">
		<?php echo $errors->first('telefono2','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="w-100"></div> 
	<div class="col-md-4 form-group">
		<label>Extensión del teléfono secundario</label>
		<input type="text" name="extension2" id="extension2" class="form-control" value="<?php echo e(old('extension2', $contacto->extension2)); ?>">
		<?php echo $errors->first('extension2','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-4 form-group">
		<label>Horario de atención</label>
		<input type="text" name="horario" id="horario" class="form-control" value="<?php echo e(old('horario', $contacto->horario)); ?>">
		<?php echo $errors->first('horario','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-4 form-group">
		<label>Dirección</label>
		<input type="text" name="direccion" id="direccion" class="form-control" value="<?php echo e(old('direccion', $contacto->direccion)); ?>">
		<?php echo $errors->first('direccion','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="w-100"></div>
	<button class="btn btn-outline-primary"><?php echo e($btnText); ?></button>
</div> 
<?php /**PATH /var/www/html/bienal/resources/views/admin/contactoFormulario.blade.php ENDPATH**/ ?>