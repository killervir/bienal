
<?php $__env->startSection('content'); ?>

<div class="lista_prensa mb-5">
	<div class="container">
		<h1 class="mb-5">Prensa</h1>
        <div class="row">
		<?php $__currentLoopData = $prensa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			
				<div class="col-md-4 item">
					<a href="<?php echo e(route('prensaDetalle', $p->slug)); ?>" class="img-nota">
						<img src="<?php echo e(asset('public/storage/prensas/'.$p->imagen)); ?>" alt="">
					</a>
					<h2><a href="<?php echo e(route('prensaDetalle', $p->slug)); ?>"><?php echo e($p->titulo); ?></a></h2>
                    <p class="c-rojo"><?php echo e($p->fecha_publica); ?> </p>
					<h3><?php echo e($p->subtitulo); ?></h3>
                    
					
				</div>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
	</div>
</div>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bienal/resources/views/prensa/lista.blade.php ENDPATH**/ ?>