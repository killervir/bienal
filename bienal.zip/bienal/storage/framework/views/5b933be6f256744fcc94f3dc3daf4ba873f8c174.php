<?php echo csrf_field(); ?>
<div class="row">
	<div class="col-md-6 form-group">
		<label>*Rol</label>
		<input required type="text" name="rol" id="rol" class="form-control" value="<?php echo e(old('rol', $rol->rol)); ?>">
		<?php echo $errors->first('rol','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

    </div>
</div>
<div class="row">
	<div class="col-md-12 form-group">
		<label>Descripción</label>
		<textarea name="descripcion" id="descripcion" class="form-control" cols="10" rows="10"><?php echo e(old('descripcion', $rol->descripcion)); ?></textarea>
		<?php echo $errors->first('descripcion','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

    </div>
    <div class="w-100"></div> 
	<button class="btn btn-outline-primary"><?php echo e($btnText); ?></button>
</div> 
<?php /**PATH /var/www/html/bienal/resources/views/admin/rolFormulario.blade.php ENDPATH**/ ?>