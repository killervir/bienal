
<?php $__env->startSection('content'); ?>
<form role="form" action="<?php echo e(route('admin.guardarActividad')); ?>" enctype="multipart/form-data" method="post">
	<h1>Crear actividad</h1>
	<?php echo $__env->make('admin.formularioActividad',['btnText'=>'Enviar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bienal/resources/views/admin/crearActividad.blade.php ENDPATH**/ ?>