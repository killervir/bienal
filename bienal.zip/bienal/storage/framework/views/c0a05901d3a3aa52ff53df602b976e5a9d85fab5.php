
<?php $__env->startSection('content'); ?>
<form role="form" action="<?php echo e(route('admin.guardarUsuario')); ?>" method="post">
	<h1>Crear usuario</h1>
	<?php echo $__env->make('admin.usuarioFormulario',['btnText'=>'Enviar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bienal/resources/views/admin/crearUsuario.blade.php ENDPATH**/ ?>