
<?php $__env->startSection('content'); ?>
<div class="row detalle-prensa mb-5">
	
	<div class="col-md-7">
    	<h1><?php echo e($prensa->titulo); ?></h1>
        <p class="c-rojo"><?php echo e($prensa->fecha_publica); ?></p>
    	<h2><?php echo e($prensa->subtitulo); ?> <br></h2>
        <hr>
        <div class="cuerpo">
        	<?php echo $prensa->descripcion; ?>

        </div>
    </div>
	<div class="offset-md-1 col-md-4">
    	<img src="<?php echo e(asset('public/storage/prensas/'.$prensa->imagen)); ?>" alt="">
        <?php if(isset($prensa->link_kit)): ?> 
        <a class="kit" target="_blank" href="<?php echo e($prensa->link_kit); ?>"><i class="fas fa-cloud-download-alt"></i> Kit de prensa</a>
        <?php endif; ?>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bienal/resources/views/prensa/detalle.blade.php ENDPATH**/ ?>