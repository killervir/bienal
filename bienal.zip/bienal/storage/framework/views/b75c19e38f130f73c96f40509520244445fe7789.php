<div class="row">

	<div class="offset-md-1 col-md-6 form-group">
		<label>*Tipo de postulación.</label>
		<select class="form-control" name="tipoPostulacion" id="tipoPostulacion">
		<option value="" selected hidden>Seleccione un tipo de postulación</option>
		    <?php $__currentLoopData = $tipoPostulacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		      <?php if($tp->id==old('tipoPostulacion') || $tp->id==$registro->tipoPostulacion): ?>
		        <option selected value="<?php echo e($tp->id); ?>"><?php echo e($tp->campo); ?></option>
		      <?php else: ?>
		        <option value="<?php echo e($tp->id); ?>"><?php echo e($tp->campo); ?></option>
		      <?php endif; ?>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
		<?php echo $errors->first('tipoPostulacion','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div> 
	
</div> 
<?php /**PATH /var/www/html/bienal/resources/views/partials/postulacion.blade.php ENDPATH**/ ?>