
<?php $__env->startSection('content'); ?>
<h1><center>Ya se había registrado con anterioridad.<br><br>
	<a class="btn btn-outline-danger" href="<?php echo e(route('home')); ?>">Regresar al inicio</a>
</center></h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bienal/resources/views/errors/419.blade.php ENDPATH**/ ?>