<?php $__env->startSection('content'); ?>
<div class="contacto">
  <div class="container">
    <h1 class="mb-5">Contacto</h1>
    <?php $__currentLoopData = $contacto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-12 mb-5">
      <h2 class=" c-rojo"><?php echo e($c->nombre); ?></h2>
      <?php if(isset($c->descripcion)): ?><p class="descripcion"><?php echo e($c->descripcion); ?></p><?php endif; ?>
      <div class="row pl-4 itemsrow">
        <div class="col-md-6 telefonos">
          <h3><i class="fas fa-mobile-alt"></i> Télefono</h3>
          <div class="row">
            <div class="col-12">
              <?php if(isset($c->telefono2)): ?><h4> telefono 1</h4><?php endif; ?>
              <p> <?php echo e($c->telefono1); ?> <?php if(isset($c->extension1)): ?> ext. <?php echo e($c->extension1); ?> <?php endif; ?></p>
            </div>
            <?php if(isset($c->telefono2)): ?>
            <div class="col-12">
              <h4>telefono 2</h4>
              <p><?php echo e($c->telefono2); ?> <?php if(isset($c->extension1)): ?> ext. <?php echo e($c->extension2); ?> <?php endif; ?></p>
            </div>
			<?php endif; ?>
          </div>
			<hr>
        </div>
		<?php if(isset($c->email)): ?>
        <div class="col-md-6">
		
          <h3><i class="far fa-envelope"></i> Correo electrónico</h3>
          <p> <?php echo e($c->email); ?></p>
			<hr>
        </div>
		  <?php endif; ?>
		 <?php if(isset($c->direccion)): ?>
        <div class="col-md-6">
          <h3><i class="far fa-building"></i> Dirección</h3>
          <p> <?php echo e($c->direccion); ?></p>
			<hr>
        </div>
		 <?php endif; ?>
		  
			<?php if(isset($c->horario)): ?>
            <div class="col-md-6">
              <h3><i class="far fa-clock"></i> Horario de atención</h3>
              <p><?php echo e($c->horario); ?></p>
				<hr>
            </div>
			<?php endif; ?>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bienal/resources/views/contacto/lista.blade.php ENDPATH**/ ?>