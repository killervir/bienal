
<?php $__env->startSection('content'); ?>
<div class="panel panel-default">
  <div class="panel-heading">
     <a class="btn btn-outline-primary" href="<?php echo e(route('admin.crearRol')); ?>">Crear rol</a> <br><br>
    <div class="w-100"></div>
    <table  id="listaRol" class="table">
  <thead>
    <th>Rol</th>
    <th>Descripción</th> 
    <th>Status</th>
    <th>Acciones</th>
  </thead>
  <tbody>
    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($r->rol); ?></td>
      <td><?php echo e($r->descripcion); ?></td>
      <td><?php echo e(($r->status==1) ? 'Activo':'Inactivo'); ?></td>
       <td>
         <a data-toggle="tooltip" data-placement="top" title="Ver" class="" href="#"><i class="fas fa-folder" data-toggle="modal" data-target="<?php echo e('#ver'.$r->id); ?>"></i></a>
        <a data-toggle="tooltip" data-placement="top" title="Editar" class="" href="<?php echo e(route('admin.editarRol',$r->id)); ?>"><i class="fas fa-pencil-alt"></i></a>
        <?php if($r->status==1): ?> 
        <a data-toggle="tooltip" data-placement="top" title="Deshabilitar" class="c-rojo" href="#"><i class="far fa-eye-slash" data-toggle="modal" data-target="<?php echo e('#deshabilitar'.$r->id); ?>"></i></a></td>
        <?php elseif($r->status==0): ?>
        <a data-toggle="tooltip" data-placement="top" title="Habilitar" class="c-verde" href="#"><i class="far fa-eye" data-toggle="modal" data-target="<?php echo e('#habilitar'.$r->id); ?>"></i></a>
        <?php endif; ?>
</tr> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
  </div>
</div>

<!-- Modal  ver -->
 <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="<?php echo e('ver'.$r->id); ?>" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel"><?php echo e($r->rol); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Rol: <?php echo e($r->rol); ?><br />
    		Descripción: <?php echo e($r->descripcion); ?> 
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>        
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

<!-- Modal  deshabilitar -->
 <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="<?php echo e('deshabilitar'.$r->id); ?>" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel"><?php echo e($r->rol); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo Form::model($roles, ['method' => 'PATCH', 'route' => ['admin.deshabilitarRol', $r->id]]); ?>

          <h5> ¿Está seguro que desea deshabilitar el rol de <?php echo e('"'.$r->rol.'"'); ?></h5>
          <button class="btn btn-outline-danger">Sí, deshabilitar</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

<!-- Modal  habilitar -->
 <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="<?php echo e('habilitar'.$r->id); ?>" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel"><?php echo e($r->rol); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo Form::model($roles, ['method' => 'PATCH', 'route' => ['admin.habilitarRol', $r->id]]); ?>        
          <h5> ¿Está seguro que desea habilitar el rol de <?php echo e('"'.$r->rol.'"'); ?></h5>
          <button class="btn btn-outline-success">Sí, habilitar</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bienal/resources/views/admin/listarRoles.blade.php ENDPATH**/ ?>