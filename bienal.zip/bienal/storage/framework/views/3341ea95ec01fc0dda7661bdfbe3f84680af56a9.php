<?php $__env->startSection('content'); ?>
    <div class="container col-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h2>Listado de registros</h2>
            </div>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Folio</th>
							<th>Tipo postulación</th>							
							<th>Datos Personales</th>
							<th>Proyecto</th>
                            <th>acciones</th>
                            <th>Verificación</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo $registro->folio; ?></td>
								<td><?php echo $registro->tipoPostulacion==1 ? 'Individual' : 'Colectiva'; ?> 
								<td><a href="<?php echo e(asset('public/storage/'.$registro->documentosPersonales)); ?>" target="_blank">Ver PDF</a></td>
								<td><a href="<?php echo asset('public/storage/'.$registro->adjuntarProyecto); ?>" target="_blank">Ver Proyecto</a></td>
                                <td class="acciones-btns">
                                    <a data-toggle="tooltip" data-placement="top" title="Ver registro" class="" href="<?php echo e(route('xix.show',$registro->folio)); ?>"><i class="fas fa-folder"></i></a>
                                    <?php if(auth()->user()->hasRoles([5])): ?>
                                    <a data-toggle="tooltip" data-placement="top" title="Editar" class="" href="<?php echo e(route('xix.edit',$registro->folio)); ?>"><i class="fas fa-pencil-alt"></i></a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($registro->verificacion==0): ?>
                                    <a data-toggle="tooltip" data-placement="top" title="Verificar" class="c-verde" href="#"><i class="fas fa-check" data-toggle="modal" data-target="<?php echo e('#verificar'.$registro->folio); ?>"></i></a>
                                    <?php elseif($registro->verificacion==1): ?>
                                    <font color="green">Verificado</font>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
			    <?php echo e($registros->links()); ?>

        </div>
    </div>
<!-- Modal  verificar -->
<?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="<?php echo e('verificar'.$r->folio); ?>" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel"><?php echo e($r->folio); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo Form::model($registro, ['method' => 'PATCH', 'route' => ['admin.verificarRegistro', $r->folio]]); ?>        
          <h5> ¿Está seguro que desea verificar el registro con el folio <?php echo e('"'.$r->folio.'"'); ?></h5>
          <button class="btn btn-success">Sí, verificar</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bienal/resources/views/admin/listadoRegistro.blade.php ENDPATH**/ ?>