
<?php $__env->startSection('content'); ?>
<?php echo csrf_field(); ?>
<form role="form" action="<?php echo e(route('xix.update',$registro->folio)); ?>" method="post" enctype="multipart/form-data">
	<?php echo method_field('patch'); ?>
<title>Editar registro </title>

	<div class="row">
	<div class="col-md-12">
		<h1>Editar registro</h1>
		<p>*Estos campos son obligatorios</p>
		<br>
	</div> 
	</div> 
	<div class="col-md-12">
		<h1>folio de registro: <?php echo e($registro->folio); ?></h1>
	</div>
	<div class="row">
		<div class="col-md-12">
			<?php if($registro->tipoPostulacion==1): ?>
			<h2>Postulación <?php echo e('individual'); ?> </h2>
			<h3>Información de contacto</h3>
			<?php elseif($registro->tipoPostulacion==2): ?>
			<h2>Postulación <?php echo e('colectiva'); ?> </h2>
			<h3>Información del representante</h3>
			<?php endif; ?>
		</div>
	</div>
	<?php echo $__env->make('partials.formularioGeneral', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php if($registro->tipoPostulacion==2): ?>
		<div class="col-md-12">
		<h3>Información del colectivo</h3>
		<br><?php echo $__env->make('partials.rowColectiva', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
		<div class="col-md-6">
			<h4>Eliminar integrantes</h4>
			<table class="table">
				<thead>
					<tr>
						<th>Integrante</th>
						<th>Eliminar</th>
					</tr>
				</thead>
				<tbody>
			<?php $__currentLoopData = $integrantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $integrante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<tr>
						<td><?php echo e($integrante->integrante); ?></td>
						<td>
							<a data-toggle="tooltip" data-placement="top" title="Eliminar" class="c-verde" href="<?php echo e(route('xix.cEliminarIntegrante',$integrante->id)); ?>"><i class="fas fa-trash"></i></a>
						</td>
					</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</tbody>
			</table>
		</div>
	<?php endif; ?>

	<?php echo $__env->make('partials.proyecto', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
	<?php echo $__env->make('partials.condiciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
	<div class="row">
		<div class="col-md-12 text-center mt-5 mb-3">
			<button type="submit" class="btn btn-outline-success">Actualizar</button>
			<br><br>
		</div>
	</div> 

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bienal/resources/views/registro/edit.blade.php ENDPATH**/ ?>