<?php $__env->startSection('content'); ?>
<div class="">
	<div class="container">
		<h1>Preguntas frecuentes</h1>
		<ul class="preguntas_frecuentes">
			<?php $__currentLoopData = $preguntasFrecuentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($faq->pregunta); ?></li>
				<ul>
					<li><?php echo e($faq->respuesta); ?></li>
				</ul>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bienal/resources/views/preguntasFrecuentes/lista.blade.php ENDPATH**/ ?>