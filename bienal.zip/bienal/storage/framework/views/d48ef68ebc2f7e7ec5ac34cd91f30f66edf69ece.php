<?php echo csrf_field(); ?>
<div class="row">
	<div class="col-md-6 form-group">
		<label>*Usuario</label>
		<input required type="text" name="name" id="name" class="form-control" value="<?php echo e(old('name', $usuario->name)); ?>">
		<?php echo $errors->first('name','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-6 form-group">
		<label>Correo electrónico</label>
		<input type="email" name="email" id="email" class="form-control" value="<?php echo e(old('email', $usuario->email)); ?>">
		<?php echo $errors->first('email','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

    </div>	
    <div class="w-100"></div>
    <div class="col-md-6 form-group">
        <label>Contraseña</label>        
            <input id="password" type="password" class="form-control" name="password">            
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo $errors->first('password','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>        
    </div>
    <div class="col-md-6 form-group">
        <label>Confirmar contraseña</label>        
            <input id="password-confirm" type="password" class="form-control" name="password_confirmation">        
    </div>
    <div class="w-100"></div>    
    <div class="row terminos">
        <label>Permisos</label>
        
        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="offset-md-1 col-md-11 form-group">
            <input type="checkbox" name="roles[]" value=<?php echo e($rol->id); ?>  <?php echo e(old('roles',$usuario->roles->contains($rol->id))?'checked':null); ?>>
        <label><?php echo e($rol->rol); ?></label> 
            <?php echo $errors->first('roles','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?><br>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div> 
    <div class="w-100"></div>
	<button class="btn btn-outline-primary"><?php echo e($btnText); ?></button>
</div> 
<?php /**PATH /var/www/html/bienal/resources/views/admin/usuarioFormulario.blade.php ENDPATH**/ ?>