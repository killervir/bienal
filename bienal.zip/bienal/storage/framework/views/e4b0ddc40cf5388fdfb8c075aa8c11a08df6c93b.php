<div class="row">
	<div class="col-md-12">
		<h3><center><font>Sobre el proyecto</font></center></h3>
	</div>
</div> 
<div class="row">
	<div class="col-md-4 form-group">
		<label>Disciplina</label>
		<select name="disciplina" id="disciplina" class="form-control" value="<?php echo e(old('disciplina')); ?>">
			<option value="null" hidden disabled selected>Seleccione una opción</option>
			<option value="1">Fotografía / Imagen fija</option>
			<option value="2">Video / Imagen en movimiento</option>
			<option value="3">Instalación /Mixta </option>
		</select>
		<?php echo $errors->first('disciplina','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-4 form-group">
		<label>Título de proyecto</label>
		<input type="text" name="tituloProyecto" id="tituloProyecto" class="form-control" placeholder="Ej. Tonatzin al atardecer" value="<?php echo e(old('tituloProyecto')); ?>">
		<?php echo $errors->first('tituloProyecto','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-4 form-group">
		<label>Año de realización</label>
		<input type="number" name="anoRealizacion" id="anoRealizacion" class="form-control" placeholder="Ej. 2019" value="<?php echo e(old('anoRealizacion')); ?>">
		<?php echo $errors->first('anoRealizacion','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
</div> 
<div class="row">
	<div class="col-md-4 form-group">
		<label>Descripción</label>
		<textarea name="descripcionProyecto" id="descripcionProyecto" class="form-control" placeholder="Ej. descripción"><?php echo e(old('descripcionProyecto')); ?></textarea>
		<?php echo $errors->first('descripcionProyecto','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-4 form-group">
		<label>Adjuntar proyecto</label>
		<input type="file" name="adjuntarProyecto" id="adjuntarProyecto" class="form-control" value="<?php echo e(old('adjuntarProyecto')); ?>">
		<p><font color="blue">Un solo documento (PDF, no mayor a 15MB) que incluya: Nombre del proyecto, Año de realización del proyecto, Descripción de la obra, sea serie o pieza única, ,Imagen(es) de la obra, Ficha técnica de la obra, sea serie o pieza única, con la siguiente información:  Título de la obra, Año de realización, Técnica, Medidas ,Duración (sólo en caso de obras en video, Enlace(s) y contraseña(s) de acceso para visualización en Internet (sólo en caso de obras en video), Avalúo de la obra y de cada uno de sus componentes (para fines de aseguramiento), Esquema o croquis de montaje.</font></p>
		<?php echo $errors->first('adjuntarProyecto','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
</div> 
<div class="row">
	<div class="col-md-6 form-group">
		<input type="checkbox" name="bases" value=" bases" value="<?php echo e(old('bases')); ?>">
		<label>Acepto las bases, términos y condiciones de la presente convocatoria.</label> <br>
	</div>
	<div class="col-md-6 form-group">
		<input type="checkbox" name="privacidad" value=" privacidad" value="<?php echo e(old('privacidad')); ?>">
		<label>He leído y acepto el aviso de privacidad.</label> <br>
	</div>
</div> <?php /**PATH C:\laragon\www\bienal\resources\views/partials/proyecto.blade.php ENDPATH**/ ?>