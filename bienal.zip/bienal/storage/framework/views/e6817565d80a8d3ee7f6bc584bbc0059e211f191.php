
<?php $__env->startSection('content'); ?>
<a class="btn btn-outline-primary" href="<?php echo e(route('admin.crearfaq')); ?>">Crear Pregunta frecuente</a>
<br><br>
<div class="panel panel-default">
  <div class="panel-heading">
    <table class="table">
      <thead>
        <tr>
          <th>Convocatoria</th>
          <th>Pregunta</th>
          <th>Respuesta</th>
          <th>Acciones</th>
        </tr>
  </div>
  <div class="panel-body">
      <tbody>
        <tr>
        <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e('Bienal 2020'); ?></td>
          <td><?php echo e($f->pregunta); ?></td>
          <td><?php echo e($f->respuesta); ?></td>
          <td>
            <a data-toggle="tooltip" data-placement="top" title="Ver" class="" href="#"><i class="fas fa-folder" data-toggle="modal" data-target="<?php echo e('#ver'.$f->slug); ?>"></i></a>
            <a data-toggle="tooltip" data-placement="top" title="Editar" class="" href="<?php echo e(route('admin.editarFaq',$f->slug)); ?>"><i class="fas fa-pencil-alt"></i></a>
            <?php if($f->status==1): ?> 
            <a data-toggle="tooltip" data-placement="top" title="Deshabilitar" class="c-rojo" href="#"><i class="far fa-eye-slash" data-toggle="modal" data-target="<?php echo e('#deshabilitar'.$f->slug); ?>"></i></a></td>
            <?php elseif($f->status==0): ?>
            <a data-toggle="tooltip" data-placement="top" title="Habilitar" class="c-verde" href="#"><i class="far fa-eye" data-toggle="modal" data-target="<?php echo e('#habilitar'.$f->slug); ?>"></i></a>
            <?php endif; ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
      </tbody>
      </thead>
    </table>
  </div>
</div>
<!-- Modal  ver -->
<?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="<?php echo e('ver'.$f->slug); ?>" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel"><?php echo e($f->pregunta); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <h3>Pregunta:</h3>  
        <?php echo e($f->pregunta); ?>    <br>  <br>  
        <h3>Respuesta:</h3> 
    <?php echo e($f->respuesta); ?> <br>      
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- Modal  deshabilitar -->
<?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="<?php echo e('deshabilitar'.$f->slug); ?>" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel"><?php echo e($f->pregunta); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo Form::model($faq, ['method' => 'PATCH', 'route' => ['admin.deshabilitarFaq', $f->slug]]); ?>

          <h5> ¿Está seguro que desea deshabilitar la pregunta <?php echo e('"'.$f->pregunta.'"'); ?></h5>
          <button class="btn btn-outline-danger">Sí, deshabilitar</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- Modal  habilitar -->
<?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="<?php echo e('habilitar'.$f->slug); ?>" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel"><?php echo e($f->pregunta); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo Form::model($faq, ['method' => 'PATCH', 'route' => ['admin.habilitarFaq', $f->slug]]); ?>        
          <h5> ¿Está seguro que desea habilitar la pregunta <?php echo e('"'.$f->pregunta.'"'); ?></h5>
          <button class="btn btn-outline-success">Sí, habilitar</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bienal/resources/views/admin/listafaq.blade.php ENDPATH**/ ?>