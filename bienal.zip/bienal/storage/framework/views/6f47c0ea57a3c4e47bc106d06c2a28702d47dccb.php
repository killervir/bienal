<?php $__env->startSection('content'); ?>
<?php echo csrf_field(); ?>
<form role="form" action="<?php echo e(route('xix.store')); ?>" method="post" enctype="multipart/form-data">
	<input id="tipo" name="tipo" type="hidden" value="<?php echo e(old('tipo')); ?>">
<title>Ficha de registro </title>
<div class="container">
	<div class="row">
	<div class="col-md-12">
		<h1>Ficha de registro</h1>
		<p>*Estos campos son obligatorios</p>
		<br>
	</div> 
	</div> 
	<?php echo $__env->make('partials.postulacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <input type="hidden" name="folio" id="folio" value="<?php echo e($folio); ?>">
    <div id="divIndividual" style="display:none"> <h2>Postulación individual</h2> </div>
    <div id="divColectivo" style="display:none"><h2>Postulación colectiva</h2></div>
    <div id="divRepresentante" style="display:none"><h3>Información del representante</h3></div>
    <div id="divFormulario" style="display:none"><?php echo $__env->make('partials.formularioGeneral', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
    <div id="divColectiva" style="display:none"><h3>Información del colectivo</h3>
    	<br><?php echo $__env->make('partials.rowColectiva', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
	
	<hr>
		
		<div id="divProyecto" style="display:none"><?php echo $__env->make('partials.proyecto', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
	<div id="divCondiciones" style="display:none"><?php echo $__env->make('partials.condiciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
	
	<div class="row">
		<div class="col-md-12 text-center mt-5 mb-3">
			<button type="submit" class="btn btn-outline-success">Enviar</button>
			<br><br>
		</div>
	</div> 

</div> 
</form>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bienal/resources/views/registro/formulario.blade.php ENDPATH**/ ?>