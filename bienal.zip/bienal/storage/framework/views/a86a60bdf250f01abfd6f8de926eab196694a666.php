 
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="Description" content="La Bienal de Fotografía convoca a fotógrafos y artistas visuales residentes en México, con el propósito de reconocer e impulsar la producción fotográfica en nuestro país.">

<meta property="og:title" content="XIX Bienal de Fotografía" />
<meta property="og:type" content="website" />
<meta property="og:url" content="http://bienaldefotografia.com.mx/" />
<meta property="og:image" content="<?php echo e(asset('public/img/meta.jpg')); ?>" />
<meta property="og:description" content="La Bienal de Fotografía convoca a fotógrafos y artistas visuales residentes en México, con el propósito de reconocer e impulsar la producción fotográfica en nuestro país." />


<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

<link rel="stylesheet" href="<?php echo e(asset('public/css/styles.css')); ?>"><?php /**PATH /var/www/html/bienal/resources/views/admin/head.blade.php ENDPATH**/ ?>