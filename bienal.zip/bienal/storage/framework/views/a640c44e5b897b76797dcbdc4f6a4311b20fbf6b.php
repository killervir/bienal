<?php $__env->startSection('content'); ?>
<title>Ficha de registro</title>
<div class="container-fluid">
	<div class="row">
	<div class="col-md-12">
		<h1><center><font>XII Bienal de Fotografía</font></center></h1>
		<h2><center><font>Ficha de registro</font></center></h2>
	</div> 
	</div> 

	<div class="row">
		<div class="col-md-6 form-group">
			<label>Tipo de postulación.</label>
			<select class="form-control" name="tipoPostulacion" id="tipoPostulacion">
				<option hidden disable selected value="null">Seleccione una opción</option>
				<option value="1">Individual</option>
				<option value="2">Colectiva</option>
			</select>
			<?php echo $errors->first('tipoPostulacion','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

		</div> 
	</div> 


	<div > 
		<?php echo $__env->make('partials.formularioGeneral',['adicional'=>'','adicional2'=>'','postType'=>'Postulación Individual'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div> 


	<div hidden> 
		<?php echo $__env->make('partials.formularioGeneral',['adicional'=>'del representante','adicional2'=>'del Colectivo','postType'=>'Postulación Colectiva'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="row">
		<div class="col-md-4 form-group">
			<label>Nombre del Colectivo</label>
			<input type="text" name="nombreColectivo" id="nombreColectivo" class="form-control" value="<?php echo e(old('nombreColectivo')); ?>">
			<?php echo $errors->first('nombreColectivo','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

		</div>
		<div class="col-md-4 form-group">
			<label>Nombre completo de integrantes del colectivo</label>
			<div id="items">
			 <div><input type="text" class="form-control" name="input[]" id='integrante'></div> <br>
			 <?php echo $errors->first('integrante','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

			 <button class="btn btn-outline-primary" id="add">Agregar integrante</button>
			</div>
		</div> 
	</div> 
	</div> 

	<?php echo $__env->make('partials.proyecto', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<div class="row">
		<div class="col-md-4 form-group">
		</div>
	</div> 
	<div class="row">
		<div class="col-md-4">
			<button type="submit" class="btn btn-outline-success">Enviar</button>
		</div>
</div> 
</div> 

<?php $__env->stopSection(); ?>



<?php echo $__env->make('partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bienal\resources\views/registro/formulario.blade.php ENDPATH**/ ?>