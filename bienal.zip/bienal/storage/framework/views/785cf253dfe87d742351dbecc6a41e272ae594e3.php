
<?php $__env->startSection('content'); ?>
<div class="panel panel-default">
  <div class="panel-heading">
    <a class="btn btn-outline-primary" href="<?php echo e(route('admin.CrearUsuario')); ?>">Crear usuario</a> <br><br>
    <div class="w-100"></div>
    <table  id="listaUsuarios" class="table">
  <thead>
    <th>Usuario</th>
    <th>Correo electrónico</th>
    <th>Roles</th>
    <th>Acciones</th>
  </thead>
  <tbody>
      
    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($u->username); ?></td>
      <td><?php echo e($u->email); ?></td>
      <td>
          <?php echo e($u->roles->pluck('rol')->implode(', ')); ?>

     
      </td>
      <td>
        <a data-toggle="tooltip" data-placement="top" title="Ver usuario" class="" href="#"><i class="fas fa-folder" data-toggle="modal" data-target="<?php echo e('#ver'.$u->id); ?>"></i></a>
        <a data-toggle="tooltip" data-placement="top" title="Editar" class="" href="<?php echo e(route('admin.editarUsuario',$u->id)); ?>"><i class="fas fa-pencil-alt"></i></a>

      </td>
    </tr>
  
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php echo e($usuarios->links()); ?>

  </div>
</div>

<!-- Modal  ver -->
 <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="<?php echo e('ver'.$u->id); ?>" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel"><?php echo e($u->username); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Usuario: <?php echo e($u->name); ?><br />
    Correo electrónico: <?php echo e($u->email); ?><br />
    Roles: <?php echo e($u->roles->pluck('rol')->implode(', ')); ?>		
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

<!-- Modal  deshabilitar -->

<!-- Modal  habilitar -->
 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bienal/resources/views/admin/listaUsuarios.blade.php ENDPATH**/ ?>