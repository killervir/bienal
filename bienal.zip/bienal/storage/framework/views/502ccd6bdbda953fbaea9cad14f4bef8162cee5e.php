
<?php $__env->startSection('content'); ?>
<div class="panel panel-default">
  <div class="panel-heading">
    <a class="btn btn-outline-primary" href="<?php echo e(route('admin.crearContacto')); ?>">Crear contacto</a> <br><br>
    <div class="w-100"></div>
    <table  id="listaContactos" class="table">
  <thead>
    <th>Nombre</th>
    <th>Descripción</th>
    <th>Acciones</th>
  </thead>
  <tbody>
    <?php $__currentLoopData = $contacto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($c->nombre); ?></td>
      <td><?php echo e($c->descripcion); ?></td>
      <td>
        <a data-toggle="tooltip" data-placement="top" title="Ver contacto" class="" href="#"><i class="fas fa-folder" data-toggle="modal" data-target="<?php echo e('#ver'.$c->slug); ?>"></i></a>
        <a data-toggle="tooltip" data-placement="top" title="Editar" class="" href="<?php echo e(route('admin.editarContacto',$c->slug)); ?>"><i class="fas fa-pencil-alt"></i></a>
        <?php if($c->status==1): ?> 
        <a data-toggle="tooltip" data-placement="top" title="Deshabilitar contacto" class="c-rojo" href="#"><i class="far fa-eye-slash" data-toggle="modal" data-target="<?php echo e('#deshabilitar'.$c->slug); ?>"></i></a></td>
        <?php elseif($c->status==0): ?>
        <a data-toggle="tooltip" data-placement="top" title="Habilitar contacto" class="c-verde" href="#"><i class="far fa-eye" data-toggle="modal" data-target="<?php echo e('#habilitar'.$c->slug); ?>"></i></a>
        <?php endif; ?>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
  </div>
</div>

<!-- Modal  ver -->
<?php $__currentLoopData = $contacto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade ver-contacto" id="<?php echo e('ver'.$c->slug); ?>" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel"><?php echo e($c->nombre); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Nombre:<br> <span><?php echo e($c->nombre); ?></span></p>
		<?php if(isset($c->email)): ?>
        <p>Correo: <br> <span><?php echo e($c->email); ?></span></p>
        <?php endif; ?>
        <?php if(isset($c->descripcion)): ?>
		<p>Descripcion: <br> <span><?php echo e($c->descripcion); ?></span></p>
        <?php endif; ?>
		<p>Telefono 1: <br> <span><?php echo e($c->telefono1); ?></span> <?php if(isset($c->extension1)): ?> Ext: <span><?php echo e($c->extension1); ?></span><?php endif; ?></p>
        <?php if(isset($c->telefono2)): ?>
		<p>Telefono 2: <br> <span><?php echo e($c->telefono2); ?></span> <?php if(isset($c->extension1)): ?> Ext: <span><?php echo e($c->extension2); ?></span> <?php endif; ?> </p>
        <?php endif; ?>
        <?php if(isset($c->telefono2)): ?>
		<p>Horario: <br> <span><?php echo e($c->horario); ?></span></p>
        <?php endif; ?>
		<p>Direccion: <br> <span><?php echo e($c->direccion); ?></span></p>
      </div>
      <div class="modal-footer">
        <a  class="btn btn-outline-danger" href="<?php echo e(route('admin.editarContacto',$c->slug)); ?>">Editar</a>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- Modal  deshabilitar -->
<?php $__currentLoopData = $contacto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="<?php echo e('deshabilitar'.$c->slug); ?>" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel"><?php echo e($c->nombre); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo Form::model($contacto, ['method' => 'PATCH', 'route' => ['admin.deshabilitarContacto', $c->slug]]); ?>

          <h5> ¿Está seguro que desea deshabilitar el contacto <?php echo e('"'.$c->nombre.'"'); ?></h5>
          <button class="btn btn-outline-danger">Sí, deshabilitar</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- Modal  habilitar -->
<?php $__currentLoopData = $contacto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="<?php echo e('habilitar'.$c->slug); ?>" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel"><?php echo e($c->nombre); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo Form::model($contacto, ['method' => 'PATCH', 'route' => ['admin.habilitarContacto', $c->slug]]); ?>        
          <h5> ¿Está seguro que desea habilitar el contacto <?php echo e('"'.$c->nombre.'"'); ?></h5>
          <button class="btn btn-outline-success">Sí, habilitar</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bienal/resources/views/admin/listaContactos.blade.php ENDPATH**/ ?>