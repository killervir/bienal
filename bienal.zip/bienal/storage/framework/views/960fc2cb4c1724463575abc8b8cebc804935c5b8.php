<!doctype html>
<html lang="en">
<head>
<!-- Required meta tags -->
<?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<title>Convocatoria XIX bienal de fotografia </title>
</head>
<body class="home">
<header class="container-fluid">
  <div class="row">
    <div class="col-md-5 logo-ci"><img src="<?php echo e(asset('public/img/logo-centro-de-la-imagen.svg')); ?>" alt=""></div>
    <div class="col-md-7 logo-bienal"><img src="<?php echo e(asset('public/img/logo-xixbienal.svg')); ?>" alt=""></div>
  </div>
</header>
	<?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="bg-fff cont-m5">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h2>Convocatoria</h2>
        <div class="col-md-10 offset-md-2">
          <p>La Bienal de Fotografía convoca a fotógrafos/as y artistas visuales residentes en México, con el propósito de reconocer e impulsar la producción fotográfica en nuestro país. Dado el carácter bianual de este certamen, su función es mostrar un panorama diverso de la escena contemporánea: sus creadores en activo y sus diversas investigaciones, al tiempo que permite pensar en torno a nuestro presente y reflexionar sobre las visualidades que componen actualmente una exploración atravesada por el medio fotográfico. </p>
          <p>En sus distintas ediciones, la Bienal de Fotografía ha dado cuenta de las transformaciones del medio, tanto en su dimensión tecnológica y material como conceptual, además de permitir el mapeo de las temáticas, estrategias y medios con los que autoras y autores se han aproximado al medio.</p>
        </div>
      </div>
      <div class="col-md-6 foto"><img src="<?php echo e(asset('public/img/foto-02.jpg')); ?>" alt=""></div>
    </div>
  </div>
</div>

<div class="bases">
  <div class="container">
    <div class="row">
      <div class="col-md-12 pt-5">
        <h2 >Bases</h2>
      </div>
      <div class="col-md-8">
        <h3>1. Podrán participar:</h3>
        <p>Fotógrafas/os y artistas visuales en general, mayores de edad al cierre de la presente convocatoria:</p>
        <ul>
          <li>de nacionalidad mexicana, que residan en México o fuera del país</li>
          <li>de nacionalidad extranjera que vivan en la república mexicana, quienes deberán acreditar su residencia continua en el país por un mínimo de tres años previos a la publicación de esta convocatoria, mediante documento oficial vigente (visa de residencia temporal o permanente) expedido por el Instituto Nacional de Migración (INM) de la Secretaría de Gobernación (Segob).</li>
        </ul>
        <h3>2. No podrán participar:</h3>
        <ol start="1">
          <li>Mandos medios y superiores adscritos a cualquiera de las unidades administrativas que conforman la Secretaría de Cultura.</li>
          <li>Mandos medios y superiores, ni sus parientes en primer grado, como tampoco trabajadores adscritos al Centro de la Imagen (en adelante CI) y a las instancias patrocinadoras de la XIX Bienal de Fotografía.</li>
          <li>Parientes en primer grado de las personas que integran el Jurado.
Con referencia a los puntos anteriores, se hará una declaratoria de vínculos y de no conflicto de intereses.
</li>
        </ol>
<!--        <p>Con referencia a los puntos anteriores se hará una declaratoria de vínculos y de no conflicto de intereses&nbsp;</p>-->
        <h3>3. Sobre el Jurado</h3>
        <ol start="1">
          <li>El Jurado estará integrado por tres especialistas en las áreas de creación, investigación, curaduría y crítica de la fotografía y artes visuales. Sus nombres se darán a conocer junto con la publicación del Acta de Jurado.</li>
          <li>El Jurado seleccionará un máximo de 50 trabajos para ser exhibidos en la muestra de la XIX Bienal de Fotografía.</li>
        </ol>
        <h3>4. Sobre las obras</h3>
        <ol start="1">
          <li>Las obras participantes deberán ser propiedad de su autor/a, realizadas entre enero de 2018 y la fecha de cierre de la presente convocatoria. No deberán haber sido exhibidas, premiadas o estar en espera de dictamen en otros concursos similares, ya sean nacionales o internacionales.</li>
          <li>El tema y el número de imágenes quedan a elección de cada participante.</li>
          <li>La obra, sea serie o pieza única, en su conjunto no deberá exceder los tres metros en su lado más grande como medida final (enmarcado o montado según croquis de montaje), ni pesar más de 30 kilogramos, y deberá estar conformada por materiales que permitan su adecuada conservación, transportación y montaje futuros.</li>
          <li>No podrán registrarse obras que hayan participado en ediciones anteriores de la Bienal de Fotografía del Centro de la Imagen.</li>
        </ol>
      </div>
      <div class="col-md-4">
        <div class="fechas-importantes bg-morado ">
          <h3>Fechas importantes</h3>
          <p><strong>Apertura de la convocatoria:</strong><br>
            16 de marzo de 2020&nbsp;</p>
          <p><strong>Cierre de registro:&nbsp;</strong><br>
           28 de mayo del 2020, a las 12:00 h (horario de la Ciudad de México)</p>
          <p><strong>Resultados de la selección del jurado:</strong><br>
            10 de julio de 2020</p>
          <p><strong>Recepción de archivos digitales de obra seleccionada:</strong><br>
            11 de julio al 14 de agosto de 2020</p>
          <p><strong>Recepción de obra física:</strong><br>
            30 de julio al 25 de septiembre de 2020</p>
          <p><strong>Anuncio de resultados:</strong><br>
            10 de diciembre de 2020</p>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-2 cuadritos">
        <div class="morado"></div>
        <div class="negro"></div>
      </div>
      <div class="col-md-10">
        <h3>5. Sobre el registro de participantes</h3>
        <ol start="1">
          <li>Quienes se interesen en participar en esta convocatoria deberán llenar el formulario de registro con sus datos personales, detalles de postulación y semblanza curricular (como se solicita en la ficha de registro en la dirección web http://bienaldefotografia.com.mx), además de presentar la documentación requerida en la misma, del 16 de marzo hasta las 12:00 horas (horario de la Ciudad de México) del 28 de mayo de 2020.</li>
          <li>Solamente se permitirá un registro por concursante, en forma individual o colectiva.</li>
          <li>Para el registro de información personal y del proyecto, quienes participen deberán subir a la dirección web http://bienaldefotografia.com.mx dos archivos en formato PDF con un peso máximo de 2 MB, debidamente identificados con el nombre del/de la autor/a, sin acentos ni caracteres especiales, de la siguiente manera: apellido_nombre_ID y apellido_nombre_proyecto con los documentos cuyas características se describen a continuación:</li>
        </ol>
        <p><strong>ARCHIVO 1. DE INFORMACIÓN PERSONAL:</strong></p>
        <p><strong>Para mexicanas/os:</strong></p>
        <ul>
          <li>Nombre de las/los participantes</li>
          <li>Copia de la identificación oficial vigente (credencial de elector por ambos lados) o pasaporte.</li>
          <li>Clave única de registro de población (CURP)</li>
          <li>Currículum vitae de 3 cuartillas máximo (5000 caracteres con espacios incluidos).</li>
        </ul>
        <p><strong>Para extranjeras/os residentes en México:</strong></p>
        <ul>
          <li>Nombre de la/el participante o participantes</li>
          <li>Copia de visa de residencia vigente, expedida por el Instituto Nacional de Migración (INM).</li>
          <li>Currículum vitae de 3 cuartillas máximo (5000 caracteres con espacios incluidos).</li>
        </ul>
        <p> <strong>ARCHIVO 2. DEL PROYECTO:</strong></p>
        <ul>
          <li>Archivo PDF del proyecto (peso máximo de 15 MB):</li>
          <li>Nombre del proyecto</li>
          <li>Año de realización</li>
          <li>Descripción de la obra, sea pieza única o serie, (máximo 2000 caracteres)</li>
          <li>Imagen(es) de la obra</li>
          <li>Ficha técnica de la obra, sea pieza única o serie, con la siguiente información:
            <ul>
              <li>Título de la obra</li>
              <li>Año de realización</li>
              <li>Técnica(s) de realización</li>
              <li>Medidas (en centímetros, alto x ancho x profundidad)</li>
              <li>Duración en minutos y segundos (sólo en caso de obras en video) (*) (**)</li>
              <li>Avalúo de la obra y de cada uno de sus componentes (para fines de aseguramiento)</li>
              <li>Esquema o croquis de montaje</li>
            </ul>
          </li>
        </ul>
        <p><strong>* Para piezas de video, anexar:</strong></p>
        <ul>
          <li>Still de video 800 x 600 DPI´s en JPG</li>
          <li>Ficha técnica de la obra, serie o pieza especificando la resolución</li>
          <li>Enlace y contraseña de acceso para visualización en internet&nbsp;</li>
        </ul>
        <p><strong>** Para pieza final (en caso de ser seleccionada): archivo en alta resolución en USB además de los elementos y componentes museográficos para su instalación y resolución (por ejemplo, pantalla, DVD, media player, pedestal, base o cualquier elemento que conforme la pieza).</strong></p>
        <ol start="4">
          <li>Las/os participantes también podrán entregar su postulación en formato físico personalmente o por mensajería, en las instalaciones del Centro de la Imagen, ubicado en Plaza de la Ciudadela número 2, Centro Histórico de la Ciudad de México, C.P. 06040, en un horario de lunes a viernes de 10:00 a 15:00 horas, en un sobre cerrado, etiquetado de la siguiente manera:</li>
          <ul>
            <li>XIX Bienal de Fotografía</li>
            <li>Nombre completo del participante</li>
          </ul>
        </ol>
        <ol start="5">
          <li>Deberá incluir un CD o una USB con los archivos en formato PDF del formulario de registro y los documentos indicados en el numeral 5, inciso c.</li>
          <li>Es importante tomar en cuenta que si la entrega de la postulación se hace directamente en el CI, el material deberá llegar entre lunes y viernes en el horario mencionado en el numeral 5, inciso d. No habrá recepción de postulaciones físicas en fin de semana.</li>
          <li>No se recibirán postulaciones fuera de las fechas estipuladas para el periodo de registro. Para las postulaciones recibidas por correo postal se tomará en cuenta la fecha del matasellos. <strong>Por ninguna circunstancia se concederán prórrogas.</strong> </li>
        </ol>
      </div>
    </div>
    <div class="row">
      <div class="col-md-4 foto-cuadritos">
        <div class="foto"> <img src="<?php echo e(asset('public/img/foto-01.jpg')); ?>" alt=""> </div>
        <div class="cuadritos">
          <div class="morado"></div>
          <div class="negro"></div>
        </div>
      </div>
      <div class="col-md-8">
        <h3>6. Revisión y selección de obra</h3>
        <ol start="1">
          <li>El proceso de selección se llevará a cabo en las siguientes etapas:</li>
          <li><strong>Revisión administrativa:</strong> El CI verificará que las postulaciones registradas cumplan con los requisitos y la documentación solicitados en la presente convocatoria. Aquellas que no acrediten esta fase serán descalificadas automáticamente y quedarán fuera del concurso.</li>
          <li><strong>Preselección:</strong> El Jurado revisará las postulaciones que pasen la fase administrativa y preseleccionará un máximo de 50 obras para ser exhibidas. En esta etapa el Jurado considerará los siguientes criterios de selección:
            <ol>
              <li>Originalidad y pertinencia de la obra presentada.</li>
              <li>Relevancia temática, estética y/o conceptual de la propuesta.</li>
              <li>Procesos y ejercicios del/la autor/a.</li>
            </ol>
          </li>
          <li><strong>Resolución:</strong> A partir de la revisión física de las obras, el Jurado realizará la selección final de éstas, las cuales integrarán la muestra, y se harán acreedoras a uno de los dos premios. El Jurado evaluará la obra tal cual y como fue enviada sin hacerle edición de ningún tipo. En esta etapa tomará en cuenta que:
            <ol>
              <li>La resolución formal de la obra corresponda con la propuesta inicial (digital) presentada por su autora/or en el registro.</li>
              <li>La producción de la obra cumpla con la calidad necesaria para ser exhibida.</li>
            </ol>
          </li>
        </ol>
        <p><strong>El hecho de que una obra sea seleccionada no garantiza su inclusión en el catálogo y la exposición. Si el Jurado determina que dicha obra no cumple con los criterios antes mencionados, podrá descartarla para la muestra y el catálogo.</strong></p>
        <ol start="2">
          <li>Para evaluar y seleccionar las postulaciones registradas, el Jurado se regirá por el Código de Ética y Procedimientos de la Bienal de Fotografía del CI, publicados en la dirección web http://bienaldefotografia.com.mx</li>
          <li>El Jurado podrá solicitar entrevistas a las personas seleccionadas, que se realizarán presencialmente o vía online.</li>
          <li>El nombre de las personas seleccionadas por el Jurado será anunciado el <strong>10 de julio del 2020</strong> en la dirección web http://bienaldefotografia.com.mx y también recibirán notificación por correo electrónico.</li>
          <li>El periodo de recepción de obras físicas seleccionadas para la tercera etapa será del 13 de julio al 25 de septiembre del 2020. No habrá prórroga. Los detalles para la entrega se darán a conocer a sus respectivas/os autoras/es mediante correo electrónico.</li>
          <li>Las obras preseleccionadas deberán ser enviadas con todos los elementos y el equipo necesarios para su exhibición (incluyendo cables y contactos adecuados para su ejecución y visualización). Los costos de producción de la obra, así como los de embalaje y transporte al CI, tanto para la entrega como para la devolución, corren por cuenta de las/os autoras/es.</li>
          <li>La recepción de archivos digitales preseleccionados para su integración al catálogo será del 11 de julio al 14 de agosto de 2020, bajo las especificaciones que se enviarán por correo electrónico.</li>
          <li>El CI editará un catálogo de las obras seleccionadas por el Jurado para la muestra de la XIX Bienal de Fotografía. Cada artista participante recibirá un ejemplar. Para esta publicación, se revisarán y corregirán la descripción de la obra y la semblanza curricular del/de la autor/a, según los criterios editoriales del CI.</li>
        </ol>
        <p><strong>Las personas preseleccionadas que no entreguen los archivos digitales en tiempo y forma quedarán fuera de la publicación del catálogo.</strong></p>
      </div>
    </div>
    <div class="row">
      <div class="col-md-7">
        <h3>7.Premios</h3>
        <ol start="1">
          <li>A partir de la obra aceptada para su exhibición y montaje, según el esquema presentado en el registro, el Jurado evaluará las propuestas para otorgar dos Premios de Adquisición:</li>
          <ul>
            <li>Premio de adquisición de $70,000 (setenta mil pesos mexicanos 00/100) <strong>para artistas con hasta 10 años de ejercicio.</strong></li>
            <li>Premio de adquisición de $70,000 (setenta mil pesos mexicanos 00/100) <strong>para artistas con un ejercicio mayor a 10 años.</strong></li>
          </ul>
        </ol>
        <ol start="2">
          <li>Las obras premiadas pasarán a formar parte del acervo del CI.</li>
          <li>El Jurado tendrá la facultad del otorgar <strong>menciones honoríficas.</strong>  El número de éstas quedará a su consideración.</li>
          <li>Los premios son indivisibles y el Jurado podrá declarar desierto el Concurso o alguno de los premios, si así lo juzga pertinente (incluyendo las menciones honoríficas).</li>
          <li>El fallo del Jurado será dado a conocer en el acto inaugural de la exposición, el 10 de diciembre de 2020. Su decisión será inapelable y quedará asentada en el acta correspondiente, que será publicada en la dirección web http://bienaldefotografia.com.mx el día de la inauguración. El CI se reserva el derecho de cambiar la fecha del anuncio de los resultados.</li>
        </ol>
        <h3>8. Exposición de las obras seleccionadas</h3>
        <ol start="1">
          <li>El Centro de la Imagen determinará la curaduría y la museografía de la muestra de los trabajos seleccionados.</li>
          <li>El CI cubrirá el seguro de las obras seleccionadas desde el momento de su recepción en sus instalaciones hasta su devolución al término del periodo de exposición. No se hará cargo de daños ocasionados antes de su entrega, ni después del periodo de exposición. En caso de daño de alguna pieza u objeto que forme parte de ella, se repondrá a partir del avalúo registrado a través del aseguramiento.</li>
          <li>Cada una de las personas seleccionadas firmará un contrato en el que autorizará al CI el manejo de su obra para la exposición y el uso de las imágenes para fines exclusivamente de difusión de la XIX Bienal de Fotografía y el catálogo correspondiente.</li>
          <li>El CI se reservará el derecho de decidir cómo se incorporarán las obras ganadoras a su acervo para su conservación y resguardo.</li>
          <li>Los y las participantes contarán con plazo de 30 días naturales después de finalizar la exposición para recoger sus obras. Al término de este periodo, las obras que no hayan sido reclamadas serán destruidas quedando el CI libre de cualquier responsabilidad.</li>
          <li>Una vez inaugurada la exposición y hasta dos semanas antes de la clausura, el público visitante tendrá derecho a emitir un voto al trabajo que considere el mejor. El autor o la autora de la obra que obtenga el mayor número de votos recibirá el Premio del Público, que consiste en un reconocimiento especial. La persona ganadora será anunciada una semana antes de la clausura de la exposición.</li>
        </ol>
      </div>
		<div class="col-md-4 offset-md-1 mt-3">
      <div class="bg-gris">
        <p>El Centro de la Imagen invitará a dos especialistas a desarrollar una propuesta curatorial a partir de la muestra de los trabajos seleccionados.</p>
        <p>La participación en este concurso implica la aceptación de las bases de la presente convocatoria.</p>
        <p>El CI podrá solicitar en donación, previo acuerdo con el/la autor/a, de la o las obras (sean piezas únicas o serie) seleccionadas o no ganadoras para incorporarlas a su acervo.</p>
        <p>Proporcionar información falsa o registrar obra plagiada será motivo de descalificación automática y no se podrá volver a aplicar en futuros certámenes de la Bienal de Fotografía.</p>
        <p>Cualquier situación no prevista en esta convocatoria será resuelta por el CI.</p>
      </div>
			</div>
    </div>
  </div>
</div>
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php echo $__env->make('partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

</body>
</html><?php /**PATH /var/www/html/bienal/resources/views/bienal_web/home.blade.php ENDPATH**/ ?>