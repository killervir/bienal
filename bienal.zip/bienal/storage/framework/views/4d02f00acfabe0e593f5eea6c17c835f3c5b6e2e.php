<?php echo csrf_field(); ?>
<div class="row">
	<div class="col-md-12 form-group">
		<label>*Convocatoria</label>
		<select class="form-control" name="convocatorias_id" id="convocatorias_id">
		<option value="" selected hidden>Seleccione una convocatoria</option>
		    <?php $__currentLoopData = $convocatorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		      <?php if($c->id==old('convocatorias_id') || $c->id==$preguntasFrecuentes->convocatorias_id): ?>
		        <option selected value="<?php echo e($c->id); ?>"><?php echo e($c->titulo_convocatoria); ?></option>
		      <?php else: ?>
		        <option value="<?php echo e($c->id); ?>"><?php echo e($c->titulo_convocatoria); ?></option>
		      <?php endif; ?>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
		<?php echo $errors->first('convocatorias_id','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-12 form-group">
		<label>*Pregunta</label>
		<input type="text" name="pregunta" id="pregunta" class="form-control" value="<?php echo e(old('pregunta', $preguntasFrecuentes->pregunta)); ?>">
		<?php echo $errors->first('pregunta','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-12 form-group">
		<label>*Respuesta</label>
		<textarea name="respuesta" id="respuesta" class="form-control"><?php echo e(old('respuesta', $preguntasFrecuentes->respuesta)); ?></textarea>
		<?php echo $errors->first('respuesta','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
</div>
<button class="btn btn-outline-primary"><?php echo e($btnText); ?></button><?php /**PATH /var/www/html/bienal/resources/views/admin/formularioFaq.blade.php ENDPATH**/ ?>