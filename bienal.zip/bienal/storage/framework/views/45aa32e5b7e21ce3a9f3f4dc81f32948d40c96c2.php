<div class="row terminos">
	<div class="offset-md-1 col-md-11 form-group">
		<input type="checkbox" name="bases" value=1 <?php echo e(old('bases', $registro->bases)?'checked':null); ?>>
		<label>Acepto las bases, términos y condiciones de la presente convocatoria.</label> 
		<?php echo $errors->first('bases','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?><br>
	</div>
	<div class="offset-md-1 col-md-11 form-group">
		<input type="checkbox" name="privacidad" value=1 <?php echo e(old('privacidad', $registro->privacidad)?'checked': null); ?>>
		<label>He leído y acepto el  <a href="<?php echo e(url('https://www.gob.mx/privacidadintegral')); ?>" target="_blank">aviso de privacidad</a>.</label> <br>
		<?php echo $errors->first('privacidad','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
</div> <?php /**PATH /var/www/html/bienal/resources/views/partials/condiciones.blade.php ENDPATH**/ ?>