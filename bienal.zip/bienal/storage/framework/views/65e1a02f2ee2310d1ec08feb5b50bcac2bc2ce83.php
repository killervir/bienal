<?php echo csrf_field(); ?>
<div class="row">
	<div class="col-md-6 form-group">
		<label>*Título</label>
		<input type="text" name="titulo" id="titulo" class="form-control" value="<?php echo e(old('titulo', $actividades->titulo)); ?>">
		<?php echo $errors->first('titulo','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-6 form-group">
		<label>Imagen</label>
		<input type="file" name="imagen" id="imagen" class="form-control" value="<?php echo e(old('imagen', $actividades->imagen)); ?>">
		<?php echo $errors->first('imagen','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

		<div class="ttip bg-morado">
			<p>Sólo se admiten imágenes en formato jpg, png, bmp o jpeg.</p>
		</div>
	</div>
	<div class="col-md-6">
		<label>*Hipervínculo al facebook de la actividad</label>
		<input type="url" name="link_facebook" id="link_facebook" class="form-control" value="<?php echo e(old('link_facebook', $actividades->link_facebook)); ?>">
		<?php echo $errors->first('link_kit','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-6 form-group">
		<label>*Fecha hora de la actividad</label> 
		<input type="datetime" name="fecha_hora" id="fecha_hora" class="form-control" value="<?php echo e(old('fecha_hora', $actividades->fecha_hora)); ?>">
		<?php echo $errors->first('fecha_hora','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-12 form-group">
		<label>*resumen</label>
		<textarea name="resumen" id="resumen" class="ckeditor"><?php echo e(old('resumen', $actividades->resumen)); ?></textarea>
		<?php echo $errors->first('resumen','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
</div>
<button class="btn btn-outline-primary"><?php echo e($btnText); ?></button><?php /**PATH /var/www/html/bienal/resources/views/admin/formularioActividad.blade.php ENDPATH**/ ?>