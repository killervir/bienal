
<?php $__env->startSection('content'); ?>
<form role="form" action="<?php echo e(route('admin.actualizarFaq', $preguntasFrecuentes->slug)); ?>" enctype="multipart/form-data" method="post">
	<?php echo method_field('patch'); ?>
	<h1>Editar <?php echo e($preguntasFrecuentes->pregunta); ?></h1>
	<?php echo $__env->make('admin.formularioFaq',['btnText'=>'Actualizar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bienal/resources/views/admin/editarFaq.blade.php ENDPATH**/ ?>