
<?php $__env->startSection('content'); ?>
    <div class="container col-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h2>Listado de registros verificados</h2>
            </div>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Folio</th>
							<th>Tipo postulación</th>							
							<th>Datos Personales</th>
							<th>Proyecto</th>
                            <th>Ver</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo $registro->folio; ?></td>
								<td><?php echo $registro->tipoPostulacion==1 ? 'Individual' : 'Colectiva'; ?> 
								<td><a href="<?php echo e(asset('public/storage/'.$registro->documentosPersonales)); ?>" target="_blank">Ver PDF</a></td>
								<td><a href="<?php echo asset('public/storage/'.$registro->adjuntarProyecto); ?>" target="_blank">Ver Proyecto</a></td>
                                <td class="acciones-btns">
                                    <a data-toggle="tooltip" data-placement="top" title="Ver registro" class="" href="<?php echo e(route('xix.show',$registro->folio)); ?>"><i class="fas fa-folder"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
			    <?php echo e($registros->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bienal/resources/views/admin/verificados.blade.php ENDPATH**/ ?>