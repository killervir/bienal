    <header class="header-interiores container-fluid">
		<div class="row">
			<div class="col-md-5 logo-ci"><img src="<?php echo e(asset('public/img/logo-centro-de-la-imagen.svg')); ?>" alt=""></div>
			<div class="col-md-7 logo-bienal"><img src="<?php echo e(asset('public/img/logo-xixbienal.svg')); ?>" alt=""></div>
		</div>
	  </header><?php /**PATH /var/www/html/bienal/resources/views/partials/header.blade.php ENDPATH**/ ?>