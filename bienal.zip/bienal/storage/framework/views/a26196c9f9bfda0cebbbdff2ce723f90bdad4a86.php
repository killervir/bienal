
<?php $__env->startSection('content'); ?>
<div class="ver-registro mb-5">
<div class="row">

    <h1 class="col-md-4 offset-md-2">folio de registro: <br> <span> <?php echo e($registro->folio); ?></span></h1>
    <?php if(auth()->user()->hasRoles([5])): ?>
    <div class="col-md-4 mb-5">	
    	<a class="btn btn-outline-success" href="<?php echo e(route('xix.edit',$registro->folio)); ?>" class="btn btn-outline-secondary">Editar</a>
    </div>
    <?php endif; ?>
    
    <div class="col-md-12 mt-4">
        <?php if($registro->tipoPostulacion==1): ?>
        <h3>Tipo de postulación: <br><span><?php echo e('Individual'); ?></span> </h3>
        <?php elseif($registro->tipoPostulacion==2): ?>
        <h3>Tipo de postulación: <br><span><?php echo e('Colectiva'); ?></span> </h3>
        <?php endif; ?>
    </div>
    
   
</div>

<div class="row">
    <div class="col-md-12">
        <?php if($registro->tipoPostulacion==1): ?>
        <h2>Información de contacto</h2>
        <?php elseif($registro->tipoPostulacion==2): ?>
        <h2>Información del representante</h2>
        <?php endif; ?>
    </div>

    <div class="col-md-6">
        <h3>Nombre completo: <br><span> <?php echo e($registro->nombre); ?> <?php echo e($registro->apellidoPaterno); ?> <?php echo e($registro->apellidoMaterno); ?></span></h3>
        
        <h3>Fecha de nacimiento: <br><span><?php echo e($registro->fechaNacimiento); ?> </h3></span>
        
        <h3>Nacionalidad: <br><span><?php echo e($nacionalidad->gentilicio_nac); ?></span> </h3>
    </div>
    <div class="col-md-6">
        <h3>Lugar de residencia:  <br><span><?php echo e($registro->lugarResidencia); ?></span> </h3>
        <h3>Correo electrónico:  <br><span><?php echo e($registro->email); ?></span> </h3>
        <h3>Teléfono:  <br><span><?php echo e($registro->telefono); ?> <?php if(isset($registro->extension)): ?> extensión: <?php echo e($registro->extension); ?> <?php endif; ?></span></h3>
    
    </div>
    <div class="col-md-12 texto-largo">
        <h3>Semblanza:</h3>
        <p> <?php echo e($registro->semblanza); ?> </p>
    </div>
    <div class="col-md-6">
    	<h3>Documentos personales: <br><span><a href="<?php echo e(asset('public/storage/'.$registro->documentosPersonales)); ?>" target="_blank"><i class="fas fa-file-pdf"></i> Ver PDF</a></span> </h3>
    </div>
</div>

<?php if($registro->tipoPostulacion==2): ?>
<div class="row">
	<div class="col-md-12">
    	<h2>Sobre el colectivo</h2>
    </div>

    <div class="col-md-6">
        <h3>Nombre del colectivo: <br><span><?php echo e($registro->nombreColectivo); ?></span></h3>
    </div>
    <div class="col-md-6">
        <h3>Integrantes: </h3>
        <p> <?php $__currentLoopData = $integrantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($i->integrante); ?> <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
    </div>
</div>
<?php endif; ?>

    <div class="row">
            <div class="col-md-12">
                <h2>Sobre el proyecto</h2>
            </div>
            <div class="col-md-6">
                <h3>Disciplina: <br><span><?php echo e($disciplina->disciplina); ?></h3>
                <h3>Título del proyecto: <br><span><?php echo e($registro->tituloProyecto); ?></h3>
            </div>
            <div class="col-md-6">
                <h3>Año de realización: <br><span><?php echo e($registro->anoRealizacion); ?></h3>
                <h3>Proyecto adjunto: <br><span><a href="<?php echo asset('public/storage/'.$registro->adjuntarProyecto); ?>" target="_blank"><i class="fas fa-file-pdf"></i> Ver PDF</a></h3>
                
            </div>
            <div class="col-md-12 texto-largo">
                <h3>Descripción: </h3>
                <p><?php echo e($registro->descripcionProyecto); ?></p>
            </div>
    
    </div>
	
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bienal/resources/views/registro/ver.blade.php ENDPATH**/ ?>