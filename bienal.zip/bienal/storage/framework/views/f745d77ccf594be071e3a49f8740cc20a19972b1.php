<!DOCTYPE html>
<head>
	<?php echo $__env->make('admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
	<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make('admin.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="cont-admin container-fluid">
    <div class="col-12 text-right">
		<a class="btn btn-danger mt-4 mb-4" href="<?php echo e(route('logout')); ?>"  onclick="event.preventDefault(); document.getElementById('frm-logout').submit();" tabindex="-1" aria-disabled="true">Cerrar sesión</a>
		<form id="frm-logout" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
			<?php echo e(csrf_field()); ?>

		</form>
     </div>
		<?php echo $__env->yieldContent('content'); ?>
	</div>
	<?php echo $__env->make('admin.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html> <?php /**PATH /var/www/html/bienal/resources/views/admin/layout.blade.php ENDPATH**/ ?>