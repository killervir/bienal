
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('xix.eliminarIntegrante', $integrante->id)); ?>" method="post">
	<?php echo method_field('delete'); ?> <?php echo csrf_field(); ?>
	<h4>¿Está seguro que desea eliminar al integrante <?php echo e($integrante->integrante); ?>?</h4>
          <button class="btn btn-success">Sí, eliminar</button>
</form>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bienal/resources/views/registro/cEliminarIntegrante.blade.php ENDPATH**/ ?>