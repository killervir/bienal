<?php echo csrf_field(); ?>
<div class="row">
	<div class="mb-3 col-md-12">
		
	</div> 
</div> 
<div class="row">
	<div class="offset-md-1 col-md-3 form-group">
		<label>*Nombre</label>
		<input type="text" name="nombre" id="nombre" class="form-control" value="<?php echo e(old('nombre', $registro->nombre)); ?>">
		<?php echo $errors->first('nombre','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-4 form-group">
		<label>*Apellido 1</label>
		<input type="text" name="apellidoPaterno" id="apellidoPaterno" class="form-control" value="<?php echo e(old('apellidoPaterno', $registro->apellidoPaterno)); ?>">
		<?php echo $errors->first('apellidoPaterno','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-4 form-group">
		<label>Apellido 2</label>
		<input type="text" name="apellidoMaterno" id="apellidoMaterno" class="form-control" value="<?php echo e(old('apellidoMaterno', $registro->apellidoMaterno)); ?>">
		<?php echo $errors->first('apellidoMaterno','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
</div> 
<div class="row">
	<div class="offset-md-1 col-md-3 form-group">
		<label>*Fecha de nacimiento</label>
		<input type="date" name="fechaNacimiento" id="fechaNacimiento" class="form-control" value="<?php echo e(old('fechaNacimiento', $registro->fechaNacimiento)); ?>">
		<?php echo $errors->first('fechaNacimiento','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-4 form-group">
		<label>*Nacionalidad</label>
		<select class="form-control" name="id_nacionalidad" id="id_nacionalidad">
		<option value="" selected hidden>Seleccione una nacionalidad</option>
		    <?php $__currentLoopData = $nacionalidad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		      <?php if($n->id==old('id_nacionalidad') || $n->id==$registro->id_nacionalidad): ?>
		        <option selected value="<?php echo e($n->id); ?>"><?php echo e($n->gentilicio_nac); ?></option>
		      <?php else: ?>
		        <option value="<?php echo e($n->id); ?>"><?php echo e($n->gentilicio_nac); ?></option>
		      <?php endif; ?>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
		<?php echo $errors->first('id_nacionalidad','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-4 form-group">
		<label>*Lugar de residencia</label>
		<input type="text" name="lugarResidencia" id="lugarResidencia" class="form-control" value="<?php echo e(old('lugarResidencia', $registro->lugarResidencia)); ?>">
		<?php echo $errors->first('lugarResidencia','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>

</div> 
<div class="row">
	<div class="offset-md-1 col-md-5 form-group">
		<label>*Correo electrónico</label>
		<input type="email" name="email" id="email" class="form-control" value="<?php echo e(old('email', $registro->email)); ?>">
		<?php echo $errors->first('email','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-5 form-group">
		<label>*Confirmación del correo electrónico</label>
		<input type="email" name="emailConfirmacion" id="emailConfirmacion" class="form-control" value="<?php echo e(old('emailConfirmacion', $registro->email)); ?>">
		<?php echo $errors->first('emailConfirmacion','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>

		<div class="offset-md-1 col-md-5 form-group">
		<label>*Teléfono fijo o movil de contacto</label>
		<input type="number" name="telefono" id="telefono" class="form-control numerito" value="<?php echo e(old('telefono', $registro->telefono)); ?>">
		<?php echo $errors->first('telefono','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
		<div class="col-md-5 form-group">
		<label>Extensión</label>
		<input type="number" name="extension" id="extension" class="form-control" value="<?php echo e(old('extension', $registro->extension)); ?>">
		<?php echo $errors->first('extension','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
</div> 
<div class="row">

	<div class="offset-md-1 col-md-10 form-group">
		<label>*Semblanza</label>
		<textarea name="semblanza" id="semblanza" class="form-control"><?php echo e(old('semblanza', $registro->semblanza)); ?></textarea>
		<?php echo $errors->first('semblanza','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="offset-md-1 col-md-10 form-group">
		<label>*Adjuntar documentos personales</label>
		<input type="file" name="documentosPersonales" id="documentosPersonales" class="form-control" value="<?php echo e(old('documentosPersonales', $registro->documentosPersonales)); ?>">
		<div class="ttip bg-morado">
			<p>Un solo documento (PDF, no mayor a 2MB) con documentos personales:</p> 
			<ul>
				<li>identificación oficial vigente</li>
				<li>Curriculum vitae</li>
				<li>CURP</li>
			</ul>
			<p>*En caso de ser extranjero presentar comprobante de residencia legal en México</p>
		</div>
		
		<?php echo $errors->first('documentosPersonales','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
</div> 
<?php /**PATH /var/www/html/bienal/resources/views/partials/formularioGeneral.blade.php ENDPATH**/ ?>