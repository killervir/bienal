<div class="row">
	<div class="col-md-12">
		<h2 class="mb-5">Sobre el proyecto</h2>
	</div>
</div> 
<div class="row">
	<div class="offset-md-1 col-md-3 form-group">
		<label>*Disciplina</label>
		<select class="form-control" name="disciplina" id="disciplina">
		<option value="" selected hidden>Seleccione una disciplina</option>
		    <?php $__currentLoopData = $disciplina; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		      <?php if($d->id==old('disciplina') || $d->id==$registro->disciplina): ?>
		        <option selected value="<?php echo e($d->id); ?>"><?php echo e($d->disciplina); ?></option>
		      <?php else: ?>
		        <option value="<?php echo e($d->id); ?>"><?php echo e($d->disciplina); ?></option>
		      <?php endif; ?>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
		<?php echo $errors->first('disciplina','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-4 form-group">
		<label>*Título de proyecto</label>
		<input type="text" name="tituloProyecto" id="tituloProyecto" class="form-control" placeholder="Ej. Tonatzin al atardecer" value="<?php echo e(old('tituloProyecto', $registro->tituloProyecto)); ?>">
		<?php echo $errors->first('tituloProyecto','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="col-md-3 form-group">
		<label>*Año de realización</label>
		<input type="number" name="anoRealizacion" id="anoRealizacion" class="form-control" placeholder="Ej. 2019" value="<?php echo e(old('anoRealizacion', $registro->anoRealizacion)); ?>">
		<?php echo $errors->first('anoRealizacion','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
</div> 
<div class="row">
	<div class="offset-md-1 col-md-10 form-group">
		<label>*Descripción</label>
		<textarea name="descripcionProyecto" id="descripcionProyecto" class="form-control" placeholder="Ej. descripción"><?php echo e(old('descripcionProyecto', $registro->descripcionProyecto)); ?></textarea>
		<?php echo $errors->first('descripcionProyecto','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
	<div class="offset-md-1 col-md-10 form-group">
		<label>*Adjuntar proyecto</label>
		<input type="file" name="adjuntarProyecto" id="adjuntarProyecto" class="form-control" value="<?php echo e(old('adjuntarProyecto')); ?>">
		<div class="ttip bg-morado">
		<p>Un solo documento (PDF, no mayor a 15MB) que incluya:</p>
			<ul>
				<li>Nombre del proyecto</li>
				<li>Año de realización del proyecto</li>
				<li>Descripción de la obra sea serie o pieza única</li>
				<li>Imagen(es) de la obra</li>
				<li>Ficha técnica de la obra, sea serie o pieza única, con la siguiente información:
					<ul>
						<li>Título de la obra</li>
						<li>Año de realización</li>
						<li>Técnica</li>
						<li>Medidas</li>
						<li>Duración (sólo en caso de obras en video</li>
						<li>Enlace(s) y contraseña(s) de acceso para visualización en Internet (sólo en caso de obras en video)</li>
						<li>Avalúo de la obra y de cada uno de sus componentes (para fines de aseguramiento)</li>
						<li>Esquema o croquis de montaje</li>
					</ul>
				</li>
			</ul>
	</div>
		<?php echo $errors->first('adjuntarProyecto','<FONT COLOR="red"><strong>:message</strong></FONT>'); ?>

	</div>
</div> 
<?php /**PATH /var/www/html/bienal/resources/views/partials/proyecto.blade.php ENDPATH**/ ?>